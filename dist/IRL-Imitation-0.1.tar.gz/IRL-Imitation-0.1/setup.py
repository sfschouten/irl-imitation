
from distutils.core import setup

setup(
        name='IRL-Imitation',
        version='0.1',
        packages=['src',],
        license='MIT License',
)

