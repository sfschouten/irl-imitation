
from distutils.core import setup

setup(
        name='IRL-Imitation',
        version='0.1b',
        packages=['irl_imitation','irl_imitation/mdp'],
        license='MIT License',
)

